#!/bin/bash

FOREMAN_URL="https://10.1.13.91"
USERNAME="admin"
PASSWORD="root123"
AUTH="-u ${USERNAME}:${PASSWORD}"
HEADER="Content-Type: application/json"
PER_PAGE=20

# 'Default Location'과 'Default Organization'의 ID를 설정합니다.
# 이 ID 값은 실제 환경에서 확인한 값으로 변경해야 합니다.
DEFAULT_ORGANIZATION_ID=1
DEFAULT_LOCATION_ID=2
NAMUICT_ORGANIZATION_ID=3
RESEARCH_LOCATION_ID=4

update_resource() {
    local resource_type=$1
    local resource_id=$2
    echo "Updating ${resource_type} ID ${resource_id} with new location and organization IDs..."

    # API를 통해 현재 리소스의 JSON 데이터를 가져옵니다.
    local update_data="{\"${resource_type}\": {\"location_ids\": [$DEFAULT_LOCATION_ID, $RESEARCH_LOCATION_ID], \"organization_ids\": [$DEFAULT_ORGANIZATION_ID, $NAMUICT_ORGANIZATION_ID]}}"

    # curl을 사용하여 PUT 요청으로 리소스를 업데이트합니다.
    curl -k -s $AUTH -H "$HEADER" -X PUT -d "$update_data" "${FOREMAN_URL}/api/${resource_type}s/${resource_id}" > /dev/null

    echo "${resource_type} ID ${resource_id} has been updated."
}

update_installation_media() {
    local resource_id=$1
    local current=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/media/${resource_id}")

    if [[ $current == *'"error"'* ]]; then
        echo "Error fetching media ID ${resource_id}: $current"
        return 1
    fi

    # Parse current locations and organizations without duplicates
    local current_location_ids=$(echo $current | jq -r '.locations | map(.id) | unique | join(",")')
    local current_organization_ids=$(echo $current | jq -r '.organizations | map(.id) | unique | join(",")')

    # Build new lists ensuring no duplicates
    local new_location_ids=$(echo "$current_location_ids,$DEFAULT_LOCATION_ID,$RESEARCH_LOCATION_ID" | tr ',' '\n' | sort -u | tr '\n' ',' | sed 's/,$//')
    local new_organization_ids=$(echo "$current_organization_ids,$DEFAULT_ORGANIZATION_ID,$NAMUICT_ORGANIZATION_ID" | tr ',' '\n' | sort -u | tr '\n' ',' | sed 's/,$//')

    echo "Updating media ID ${resource_id} with locations: $new_location_ids and organizations: $new_organization_ids"
    local response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" -X PUT \
        -d "{\"medium\": {\"location_ids\": [$new_location_ids], \"organization_ids\": [$new_organization_ids]}}" \
        "${FOREMAN_URL}/api/media/${resource_id}")
    echo "$response"
}

update_resource_for_type() {
    local resource_type=$1
    local endpoint=$2
    local total=0
    local page=1

    # 초기 API 호출로 total 값 설정
    local response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
    echo "Initial response: $response"
    total=$(echo $response | jq '.total')
    echo "Total: $total"
    total=${total:-0}  # total이 null일 경우 0으로 설정

    while [ $((PER_PAGE * (page-1))) -lt $total ]; do
        local ids=$(echo $response | jq '.results | .[] | .id')
        echo "Page: $page, IDs: $ids"
        for id in $ids; do
            update_resource $resource_type $id
        done
        ((page++))
        response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
        echo "Next page response: $response"
    done
}

update_media_resource_for_type() {
    local resource_type=$1
    local endpoint=$2
    local total=0
    local page=1

    # 초기 API 호출로 total 값 설정
    local response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
    echo "Initial response: $response"
    total=$(echo $response | jq '.total')
    echo "Total: $total"
    total=${total:-0}  # total이 null일 경우 0으로 설정

    while [ $((PER_PAGE * (page-1))) -lt $total ]; do
        local ids=$(echo $response | jq '.results | .[] | .id')
        echo "Page: $page, IDs: $ids"
        for id in $ids; do
            update_installation_media $id
        done
        ((page++))
        response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
        echo "Next page response: $response"
    done
}

update_resource_for_type "provisioning_template" "provisioning_templates"
#update_resource_for_type "job_template" "job_templates"
#update_resource_for_type "ptable" "ptables"
#update_media_resource_for_type "medium" "media"

# lock all the templates
#sh lock.sh

