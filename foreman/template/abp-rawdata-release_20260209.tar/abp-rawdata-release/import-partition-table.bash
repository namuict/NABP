#!/bin/bash

my_location=$(hammer --no-headers --output csv location list --fields Name | head --lines=1)
my_organization=$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)

hammer --no-headers --output csv partition-table list --fields Name > ./existed.txt

if [ "$(grep -x "ABP Kickstart Null" ./existed.txt)" = "ABP Kickstart Null" ]; then
  hammer partition-table update --name "ABP Kickstart Null" --os-family Redhat --file "./partition-table/191.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer partition-table create --name "ABP Kickstart Null" --os-family Redhat --file "./partition-table/191.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart root" ./existed.txt)" = "ABP Kickstart root" ]; then
  hammer partition-table update --name "ABP Kickstart root" --os-family Redhat --file "./partition-table/192.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer partition-table create --name "ABP Kickstart root" --os-family Redhat --file "./partition-table/192.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default" ./existed.txt)" = "ABP Preseed default" ]; then
  hammer partition-table update --name "ABP Preseed default" --os-family Debian --file "./partition-table/193.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer partition-table create --name "ABP Preseed default" --os-family Debian --file "./partition-table/193.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default autoinstall" ./existed.txt)" = "ABP Preseed default autoinstall" ]; then
  hammer partition-table update --name "ABP Preseed default autoinstall" --os-family Debian --file "./partition-table/194.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer partition-table create --name "ABP Preseed default autoinstall" --os-family Debian --file "./partition-table/194.erb" --organization "${my_organization}" --location "${my_location}"
fi

/usr/bin/rm -f ./existed.txt

