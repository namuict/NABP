#!/bin/bash

function check_cmd(){
   # Check command and return results
   # check_cmd "<name>" "<command> <option1> ..."
   local xxx=${1}
   shift 1
   local yyy=$(${@})
   if [ _"${yyy}" = _ ]; then echo "${xxx} does not exist."; exit 1; fi
   echo -n "${yyy}" | sort | sed ':a;N;$!ba;s|\n| |g'
}

function create_hostgroup() {
  xxx="$1"
  xxx_hg_os=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Operating System".Name')
  xxx_hg_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name')
  xxx_hg_desc=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Description')
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')

  if [ _"${xxx_hg_os}" = _null ]; then
    if [ _"${xxx_hg_parent}" = _null ]; then
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --description "${xxx_hg_desc}" \
      --location "${MY_LOC}" \
      --organization "${MY_ORG}"
      sleep 1
    else
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --parent "${xxx_hg_parent}" \
      --description "${xxx_hg_desc}" \
      --location "${MY_LOC}" \
      --organization "${MY_ORG}"
      sleep 1
    fi
  else
    xxx_hg_arch=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Architecture".Name')
    xxx_hg_part=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Partition Table".Name')
    xxx_hg_pxe_loader=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."PXE Loader"')
    xxx_hg_medium=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Medium".Name')


    if [ _"${xxx_hg_parent}" = _null ]; then
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --description "${xxx_hg_desc}" \
      --organization "${MY_ORG}" \
      --location "${MY_LOC}" \
      --architecture "${xxx_hg_arch}" \
      --operatingsystem "${xxx_hg_os}" \
      --partition-table "${xxx_hg_part}" \
      --pxe-loader "${xxx_hg_pxe_loader}" \
      --root-password 'root12#$%' \
      --medium "${xxx_hg_medium}"
      sleep 1
    else
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      echo "hammer hostgroup create --name "${xxx_hg_name}" --parent "${xxx_hg_parent}" --description "${xxx_hg_desc}" --organization "${MY_ORG}" --location "${MY_LOC}" --architecture "${xxx_hg_arch}" --operatingsystem "${xxx_hg_os}" --partition-table "${xxx_hg_part}" --pxe-loader "${xxx_hg_pxe_loader}" --root-password 'root12#$%' --medium "${xxx_hg_medium}" "

      hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --parent "${xxx_hg_parent}" \
      --description "${xxx_hg_desc}" \
      --organization "${MY_ORG}" \
      --location "${MY_LOC}" \
      --architecture "${xxx_hg_arch}" \
      --operatingsystem "${xxx_hg_os}" \
      --partition-table "${xxx_hg_part}" \
      --pxe-loader "${xxx_hg_pxe_loader}" \
      --root-password 'root12#$%' \
      --medium "${xxx_hg_medium}"
      sleep 1
    fi
  fi
}

MY_HOSTNAME=$(hostname -f)
HAMMER_CMD=$(check_cmd "hammer command" /usr/bin/which hammer)
JQ_CMD=$(check_cmd "jq command" /usr/bin/which jq)
#MY_LOC=$(check_cmd "Location" hammer --no-headers --output csv location list --fields Name | head --lines=1)
#MY_ORG=$(check_cmd "Organization" hammer --no-headers --output csv organization list --fields Name | head --lines=1)

export MY_LOC="Research"
export MY_ORG="NamuICT"
export my_location="Research"
export my_organization="NamuICT"

MY_DNS=$(check_cmd "Domain" hammer --no-headers --output csv domain list --fields Name | head --lines=1)
MY_PROXY=$(check_cmd "Proxy" hammer --no-headers --output csv proxy list --fields Name | head --lines=1)

echo "Create medium from files at ./backup_medum dir"

if [ ! -f ./.abpenv ]; then echo ".abpenv file does not exist!"; exit 1; fi
if [ ! -d ./backup_medum/ ]; then echo "./backup_medum directory does not exist!"; exit 1; fi

source ./.abpenv

echo "[ABP-SETUP] Importing partition tables"
bash ./import-partition-table.bash
sleep 1
echo "[ABP-SETUP] Importing job templates"
bash ./import-job-template.bash
sleep 1
echo "[ABP-SETUP] Importing provisioning templates"
bash ./import-template.bash
sleep 1

for xxx in ./backup_medum/*
do
  xxx_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name')
  xxx_key=$(echo "${xxx_name}" | tr -s '[:punct:]' '_')
  xxx_path=$(eval "echo \${${xxx_key}_path}")
  if [ _"${xxx_path}" = _ ]; then
    echo "${xxx_name}_path variables does not set. Use information from backup."
    xxx_path=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Path')
  fi
  xxx_family=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."OS Family"')
  xxx_family=${xxx_family:="Redhat"}
  if [ _"${xxx_family}" = _null ]; then xxx_family=Redhat; fi

  echo "[ABP-SETUP] Creating medium ${xxx_name}"
  hammer medium create \
  --name "${xxx_name}" \
  --location "${MY_LOC}" \
  --organization "${MY_ORG}" \
  --os-family "${xxx_family}" \
  --path "${xxx_path}"
  sleep 1
done

echo "Create OS from files at ./backup_os dir"

if [ ! -d ./backup_os/ ]; then echo "./backup_os directory does not exist!"; exit 1; fi

for xxx in ./backup_os/*
do
  xxx_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name')
  xxx_rname=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Release')
  xxx_desc=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Title')
  xxx_major=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Major version"')
  xxx_family=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Family')
  if [ _"${xxx_family}" = _null ]; then xxx_family=Redhat; fi
  xxx_arch=$(/usr/bin/cat ${xxx} | ${JQ_CMD} '.Architectures[].Name' | sed ':a;N;$!ba;s/\n/,/g' | tr '"' "'")
  xxx_part=$(/usr/bin/cat ${xxx} | ${JQ_CMD} '."Partition tables"[].Name' | sed ':a;N;$!ba;s/\n/,/g' | tr '"' "'")
  xxx_media=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Installation media"[0].Name')
  if [ _"${xxx_media}" = _null ]; then continue; fi

  echo "[ABP-SETUP] Creating OS ${xxx_desc}"
  hammer os create \
  --name "${xxx_name}" \
  --description "${xxx_desc}" \
  --major ${xxx_major} \
  --family "${xxx_family}" \
  --architectures "${xxx_arch}" \
  --partition-tables "${xxx_part}" \
  --media "${xxx_media}" \
  --release-name "${xxx_rname}"

  sleep 1
  echo "[ABP-SETUP] Setting Templates to OS ${xxx_desc}"

  xxx_pxe=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXELinux") | .Name')
  xxx_ipxe=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "iPXE") | .Name')
  xxx_grub2=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXEGrub2") | .Name')
  xxx_grub=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXEGrub") | .Name')
  xxx_provision=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "provision") | .Name')
  xxx_finish=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "finish") | .Name')
  xxx_user_data=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "user_data") | .Name')

  xxx_pxe_id=$(hammer --no-headers --output csv template info --name "${xxx_pxe}" --fields Id)
  xxx_ipxe_id=$(hammer --no-headers --output csv template info --name "${xxx_ipxe}" --fields Id)
  xxx_grub2_id=$(hammer --no-headers --output csv template info --name "${xxx_grub2}" --fields Id)
  xxx_grub_id=$(hammer --no-headers --output csv template info --name "${xxx_grub}" --fields Id)
  xxx_provision_id=$(hammer --no-headers --output csv template info --name "${xxx_provision}" --fields Id)
  xxx_finish_id=$(hammer --no-headers --output csv template info --name "${xxx_finish}" --fields Id)
  xxx_user_data_id=$(hammer --no-headers --output csv template info --name "${xxx_user_data}" --fields Id)
  xxx_os_id=$(hammer --no-headers --output csv os info --title "${xxx_desc}" --fields Id)


  IFS=',' all_part=(${xxx_part})
  for zzz in "${all_part[@]}"
  do
    zzz=$(echo ${zzz} | tr -d "'")
    echo "[ABP-SETUP] Add OS ${xxx_desc} to partition table ${zzz}"
    hammer partition-table add-operatingsystem --name "${zzz}" --operatingsystem-id ${xxx_os_id}
    sleep 1
  done
  IFS=' '

  for yyy in $xxx_pxe_id $xxx_ipxe_id $xxx_grub_id $xxx_grub2_id $xxx_provision_id $xxx_finish_id $xxx_user_data_id
  do  
    echo "[ABP-SETUP] Add OS ${xxx_desc} to provisioning template ID ${yyy}"
    hammer template add-operatingsystem --id="${yyy}" --operatingsystem-id="${xxx_os_id}"
    echo "[ABP-SETUP] Set OS ${xxx_desc} default provisioning template to ID ${yyy}"
    hammer os set-default-template --id="${xxx_os_id}" --provisioning-template-id=${yyy}
    sleep 1
  done

  sleep 1
done

# First pass: Create all parent groups
for xxx in ./backup_hostgrp/*; do
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')
  if [ _"${xxx_hg_parent}" = _null ]; then
    create_hostgroup "${xxx}"
  fi
done

# Second pass: Create all descendant groups
for xxx in ./backup_hostgrp/*; do
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')
  if [ _"${xxx_hg_parent}" != _null ]; then
    create_hostgroup "${xxx}"
  fi
done

hammer settings set --name 'default_locale' --value 'en'
hammer user update --login admin --locale en
hammer domain update --id 1 --dns-id 1
hammer settings set --name 'global_PXEGrub2' --value 'ABP Kickstart default PXEGrub2'
hammer settings set --name 'global_PXELinux' --value 'ABP Kickstart default PXELinux'
hammer settings set --name 'global_iPXE' --value 'ABP Kickstart default iPXE'
hammer settings set --name 'local_boot_PXEGrub2' --value 'ABP Kickstart default PXEGrub2'
hammer settings set --name 'local_boot_PXELinux' --value 'ABP Kickstart default PXELinux'
hammer settings set --name 'local_boot_iPXE' --value 'ABP Kickstart default iPXE'

bash ./backup_params/hostgrp_params_cmd.bak

