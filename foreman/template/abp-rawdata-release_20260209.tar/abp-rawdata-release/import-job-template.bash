my_location=$(hammer --no-headers --output csv location list --fields Name | head --lines=1)
my_organization=$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)

echo "Import job-templates ..."
for xxx in ./job-template/*
do
  hammer job-template import --overwrite yes --file "${xxx}" --organization "${my_organization}" --location "${my_location}"
done
