#!/bin/bash

function check_cmd(){
   # Check command and return results
   # check_cmd "<name>" "<command> <option1> ..."
   local xxx=${1}
   shift 1
   local yyy=$(${@})
   if [ _"${yyy}" = _ ]; then echo "${xxx} does not exist."; exit 1; fi
   echo -n "${yyy}" | sort | sed ':a;N;$!ba;s|\n| |g'
}

MY_HOSTNAME=$(hostname -f)
HAMMER_CMD=$(check_cmd "hammer command" /usr/bin/which hammer)
JQ_CMD=$(check_cmd "jq command" /usr/bin/which jq)
#MY_LOC=$(check_cmd "Location" hammer --no-headers --output csv location list --fields Name | head --lines=1)
#MY_ORG=$(check_cmd "Organization" hammer --no-headers --output csv organization list --fields Name | head --lines=1)

export MY_LOC="Research"
export MY_ORG="NamuICT"
export my_location="Research"
export my_organization="NamuICT"

MY_DNS=$(check_cmd "Domain" hammer --no-headers --output csv domain list --fields Name | head --lines=1)
MY_PROXY=$(check_cmd "Proxy" hammer --no-headers --output csv proxy list --fields Name | head --lines=1)


create_hostgroup() {

  xxx="$1"
  xxx_hg_os=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Operating System".Name')
  xxx_hg_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name')
  xxx_hg_desc=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Description')
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')


  echo xxx_hg_os $xxx_hg_os
  echo xxx_hg_name $xxx_hg_name
  echo xxx_hg_desc $xxx_hg_desc
  echo xxx_hg_parent $xxx_hg_parent


  sleep 3

  if [ _"${xxx_hg_os}" = _null ]; then
    if [ _"${xxx_hg_parent}" = _null ]; then
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      echo hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --description "${xxx_hg_desc}" \
      --location "${MY_LOC}" \
      --organization "${MY_ORG}"
      sleep 1
    else
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      echo hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --parent "${xxx_hg_parent}" \
      --description "${xxx_hg_desc}" \
      --location "${MY_LOC}" \
      --organization "${MY_ORG}"
      sleep 1
    fi
  else
    xxx_hg_arch=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Architecture".Name')
    xxx_hg_part=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Partition Table".Name')
    xxx_hg_pxe_loader=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."PXE Loader"')
    xxx_hg_medium=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Operating system"."Medium".Name')

  echo xxx_hg_arch $xxx_hg_arch
  echo xxx_hg_part $xxx_hg_part
  echo xxx_hg_pxe_loader $xxx_hg_pxe_loader
  echo xxx_hg_medium $xxx_hg_medium

   sleep 3

    if [ _"${xxx_hg_parent}" = _null ]; then
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      echo hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --description "${xxx_hg_desc}" \
      --organization "${MY_ORG}" \
      --location "${MY_LOC}" \
      --architecture "${xxx_hg_arch}" \
      --operatingsystem "${xxx_hg_os}" \
      --partition-table "${xxx_hg_part}" \
      --pxe-loader "${xxx_hg_pxe_loader}" \
      --root-password 'root12#$%' \
      --medium "${xxx_hg_medium}"
      sleep 1
    else
      echo "I think ..."
      echo "[ABP-SETUP] Creating Hostgroup ${xxx_hg_desc}"
      echo hammer hostgroup create \
      --name "${xxx_hg_name}" \
      --parent "${xxx_hg_parent}" \
      --description "${xxx_hg_desc}" \
      --organization "${MY_ORG}" \
      --location "${MY_LOC}" \
      --architecture "${xxx_hg_arch}" \
      --operatingsystem "${xxx_hg_os}" \
      --partition-table "${xxx_hg_part}" \
      --pxe-loader "${xxx_hg_pxe_loader}" \
      --root-password 'root12#$%' \
      --medium "${xxx_hg_medium}"
      sleep 1
    fi
  fi
}

# First pass: Create all parent groups
for xxx in ./backup_hostgrp/*; do
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')
  if [ _"${xxx_hg_parent}" = _null ]; then
    create_hostgroup "${xxx}"
  fi
done

# Second pass: Create all descendant groups
for xxx in ./backup_hostgrp/*; do
  xxx_hg_parent=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Parent.Name')
  if [ _"${xxx_hg_parent}" != _null ]; then
    create_hostgroup "${xxx}"
  fi
done



