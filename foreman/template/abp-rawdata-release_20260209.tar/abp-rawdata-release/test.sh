function check_cmd(){
   # Check command and return results
   # check_cmd "<name>" "<command> <option1> ..."
   local xxx=${1}
   shift 1
   local yyy=$(${@})
   if [ _"${yyy}" = _ ]; then echo "${xxx} does not exist."; exit 1; fi
   echo -n "${yyy}" | sort | sed ':a;N;$!ba;s|\n| |g'
}

JQ_CMD=$(check_cmd "jq command" /usr/bin/which jq)

xxx="./backup_os/1.json"

  xxx_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name')
  xxx_rname=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Release')
  xxx_desc=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Title')
  xxx_major=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Major version"')
  xxx_family=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Family')
  if [ _"${xxx_family}" = _null ]; then xxx_family=Redhat; fi
  xxx_arch=$(/usr/bin/cat ${xxx} | ${JQ_CMD} '.Architectures[].Name' | sed ':a;N;$!ba;s/\n/,/g' | tr '"' "'")
  xxx_part=$(/usr/bin/cat ${xxx} | ${JQ_CMD} '."Partition tables"[].Name' | sed ':a;N;$!ba;s/\n/,/g' | tr '"' "'")
  xxx_media=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Installation media"[0].Name')
  if [ _"${xxx_media}" = _null ]; then continue; fi

echo desc  ${xxx_desc}
echo name ${xxx_name}
echo name ${xxx_rname}
echo major ${xxx_major}
echo family ${xxx_family}
echo arch ${xxx_arch}
echo part ${xxx_part}
echo media ${xxx_media}

  #echo "[ABP-SETUP] Creating OS ${xxx_desc}"
  #hammer os create \
  #--name "${xxx_name}" \
  #--description "${xxx_desc}" \
  #--major ${xxx_major} \
  #--family "${xxx_family}" \
  #--architectures "${xxx_arch}" \
  #--partition-tables "${xxx_part}" \
  #--media "${xxx_media}" \
  #--release-name "${xxx_rname}"


 xxx_pxe=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXELinux") | .Name')
  xxx_ipxe=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "iPXE") | .Name')
  xxx_grub2=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXEGrub2") | .Name')
  xxx_grub=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "PXEGrub") | .Name')
  xxx_provision=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "provision") | .Name')
  xxx_finish=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "finish") | .Name')
  xxx_user_data=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '."Default templates"[] | select(.Kind == "user_data") | .Name')

  xxx_pxe_id=$(hammer --no-headers --output csv template info --name "${xxx_pxe}" --fields Id)
  xxx_ipxe_id=$(hammer --no-headers --output csv template info --name "${xxx_ipxe}" --fields Id)
  xxx_grub2_id=$(hammer --no-headers --output csv template info --name "${xxx_grub2}" --fields Id)
  xxx_grub_id=$(hammer --no-headers --output csv template info --name "${xxx_grub}" --fields Id)
  xxx_provision_id=$(hammer --no-headers --output csv template info --name "${xxx_provision}" --fields Id)
  xxx_finish_id=$(hammer --no-headers --output csv template info --name "${xxx_finish}" --fields Id)
  xxx_user_data_id=$(hammer --no-headers --output csv template info --name "${xxx_user_data}" --fields Id)
  xxx_os_id=$(hammer --no-headers --output csv os info --title "${xxx_desc}" --fields Id)


  echo pxe - ${xxx_pxe}
  echo ipxe - ${xxx_ipxe}
  echo grub2 - ${xxx_grub2}
  echo grub - ${xxx_grub}
  echo provision - ${xxx_provision}

 echo -------------------


  echo pxe_id - ${xxx_pxe_id}
  echo ipxe_id - ${xxx_ipxe_id}
  echo grub2_id - ${xxx_grub2_id}
  echo grub_id - ${xxx_grub_id}
  echo provision_id - ${xxx_provision_id}
  echo os_id - ${xxx_os_id}

  IFS=',' all_part=(${xxx_part})
  for zzz in "${all_part[@]}"
  do
    zzz=$(echo ${zzz} | tr -d "'")
    echo "[ABP-SETUP] Add OS ${xxx_desc} to partition table ${zzz}"
    hammer partition-table add-operatingsystem --name "${zzz}" --operatingsystem-id ${xxx_os_id}
    sleep 1
  done
  IFS=' '

  for yyy in $xxx_pxe_id $xxx_ipxe_id $xxx_grub_id $xxx_grub2_id $xxx_provision_id $xxx_finish_id $xxx_user_data_id
  do
    echo "[ABP-SETUP] Add OS ${xxx_desc} to provisioning template ID ${yyy}"
    hammer template add-operatingsystem --id="${yyy}" --operatingsystem-id="${xxx_os_id}"
    echo "[ABP-SETUP] Set OS ${xxx_desc} default provisioning template to ID ${yyy}"
    hammer os set-default-template --id="${xxx_os_id}" --provisioning-template-id=${yyy}
    sleep 1
  done

  sleep 1

