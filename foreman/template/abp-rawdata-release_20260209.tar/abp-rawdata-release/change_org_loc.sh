#!/bin/bash

FOREMAN_URL="https://10.149.0.108"
USERNAME="admin"
PASSWORD="root123"
AUTH="-u ${USERNAME}:${PASSWORD}"
HEADER="Content-Type: application/json"
PER_PAGE=20

DEFAULT_ORGANIZATION_ID=1
DEFAULT_LOCATION_ID=2
NAMUICT_ORGANIZATION_ID=3
RESEARCH_LOCATION_ID=4

# Update this to a valid domain ID
VALID_DOMAIN_ID=1

update_resource() {
    local resource_type=$1
    local resource_id=$2
    echo "Updating ${resource_type} ID ${resource_id} with new location, organization, and domain IDs..."

    # If domain_id update is not necessary, remove `"domain_id": $VALID_DOMAIN_ID` from the update_data
    local update_data="{\"${resource_type}\": {\"location_ids\": [$DEFAULT_LOCATION_ID, $RESEARCH_LOCATION_ID], \"organization_ids\": [$DEFAULT_ORGANIZATION_ID, $NAMUICT_ORGANIZATION_ID], \"domain_id\": $VALID_DOMAIN_ID}}"
    echo "Update data: $update_data"

    response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" -X PUT -d "$update_data" "${FOREMAN_URL}/api/${resource_type}s/${resource_id}")
    http_status=$(echo "$response" | tail -n 1)
    response_body=$(echo "$response" | head -n -1)
    echo "Response body: $response_body"
    echo "HTTP status: $http_status"

    if [[ $http_status == *"HTTP status: 200"* ]]; then
        echo "${resource_type} ID ${resource_id} has been updated."
    else
        echo "Failed to update ${resource_type} ID ${resource_id}. HTTP status: $http_status"
    fi
}

update_resource_for_type() {
    local resource_type=$1
    local endpoint=$2
    local total=0
    local page=1

    echo "Fetching ${resource_type} from ${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page"
    response=$(curl -v -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
    http_status=$(echo "$response" | tail -n 1)
    response_body=$(echo "$response" | head -n -1)
    echo "Initial response: $response_body"
    echo "HTTP status: $http_status"

    total=$(echo "$response_body" | jq '.total')
    echo "Total: $total"
    total=${total:-0}  # total이 null일 경우 0으로 설정

    while [ $((PER_PAGE * (page-1))) -lt $total ]; do
        echo "Processing page: $page"
        jq '.results | .[] | .id' <<< "$response_body" | while read id; do
            update_resource $resource_type $id
        done
        ((page++))
        response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page")
        http_status=$(echo "$response" | tail -n 1)
        response_body=$(echo "$response" | head -n -1)
        echo "Next page response: $response_body"
        echo "HTTP status: $http_status"
    done
}

update_installation_media() {
    local resource_id=$1
    local current=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/media/${resource_id}")

    if [[ $current == *'"error"'* ]]; then
        echo "Error fetching media ID ${resource_id}: $current"
        return 1
    fi

    # Parse current locations and organizations without duplicates
    local current_location_ids=$(echo $current | jq -r '.locations | map(.id) | unique | join(",")')
    local current_organization_ids=$(echo $current | jq -r '.organizations | map(.id) | unique | join(",")')

    # Build new lists ensuring no duplicates
    local new_location_ids=$(echo "$current_location_ids,$DEFAULT_LOCATION_ID,$RESEARCH_LOCATION_ID" | tr ',' '\n' | sort -u | tr '\n' ',' | sed 's/,$//')
    local new_organization_ids=$(echo "$current_organization_ids,$DEFAULT_ORGANIZATION_ID,$NAMUICT_ORGANIZATION_ID" | tr ',' '\n' | sort -u | tr '\n' ',' | sed 's/,$//')

    echo "Updating media ID ${resource_id} with locations: $new_location_ids and organizations: $new_organization_ids"
    local response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" -X PUT \
        -d "{\"medium\": {\"location_ids\": [$new_location_ids], \"organization_ids\": [$new_organization_ids]}}" \
        "${FOREMAN_URL}/api/media/${resource_id}")
    echo "$response"
}

update_media_resource_for_type() {
    local resource_type=$1
    local endpoint=$2
    local total=0
    local page=1

    # 초기 API 호출로 total 값 설정
    local response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page" -o response.json)
    echo "Initial response: $(cat response.json)"
    total=$(jq '.total' response.json)
    echo "Total: $total"
    total=${total:-0}  # total이 null일 경우 0으로 설정

    while [ $((PER_PAGE * (page-1))) -lt $total ]; do
        jq '.results | .[] | .id' response.json | while read id; do
            update_installation_media $id
        done
        ((page++))
        curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/${endpoint}?per_page=$PER_PAGE&page=$page" -o response.json
        echo "Next page response: $(cat response.json)"
    done
}


update_smart_proxy() {
    local resource_id=$1
    echo "Updating smart_proxy ID ${resource_id} with new location and organization IDs..."

    # Smart Proxy의 location과 organization을 업데이트할 데이터 구성
    local update_data="{\"smart_proxy\": {\"location_ids\": [$DEFAULT_LOCATION_ID, $RESEARCH_LOCATION_ID], \"organization_ids\": [$DEFAULT_ORGANIZATION_ID, $NAMUICT_ORGANIZATION_ID]}}"
    echo "Update data: $update_data"

    response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" -X PUT -d "$update_data" "${FOREMAN_URL}/api/smart_proxies/${resource_id}")
    http_status=$(echo "$response" | tail -n 1)
    response_body=$(echo "$response" | head -n -1)
    echo "Response body: $response_body"
    echo "HTTP status: $http_status"

    if [[ $http_status == *"HTTP status: 200"* ]]; then
        echo "Smart Proxy ID ${resource_id} has been updated."
    else
        echo "Failed to update Smart Proxy ID ${resource_id}. HTTP status: $http_status"
    fi
}


update_smart_proxies() {
    local total=0
    local page=1

    echo "Fetching smart proxies from ${FOREMAN_URL}/api/smart_proxies?per_page=$PER_PAGE&page=$page"
    response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/smart_proxies?per_page=$PER_PAGE&page=$page")
    http_status=$(echo "$response" | tail -n 1)
    response_body=$(echo "$response" | head -n -1)
    echo "Initial response: $response_body"
    echo "HTTP status: $http_status"

    total=$(echo "$response_body" | jq '.total')
    echo "Total: $total"
    total=${total:-0}

    while [ $((PER_PAGE * (page-1))) -lt $total ]; do
        echo "Processing page: $page"
        jq '.results | .[] | .id' <<< "$response_body" | while read id; do
            update_smart_proxy $id
        done
        ((page++))
        response=$(curl -k -s -w "\nHTTP status: %{http_code}\n" $AUTH -H "$HEADER" "${FOREMAN_URL}/api/smart_proxies?per_page=$PER_PAGE&page=$page")
        http_status=$(echo "$response" | tail -n 1)
        response_body=$(echo "$response" | head -n -1)
        echo "Next page response: $response_body"
        echo "HTTP status: $http_status"
    done
}


update_resource_for_type "domain" "domains"
update_resource_for_type "subnet" "subnets"
update_resource_for_type "hostgroup" "hostgroups"
update_resource_for_type "provisioning_template" "provisioning_templates"
update_resource_for_type "job_template" "job_templates"
update_resource_for_type "ptable" "ptables"
update_media_resource_for_type "medium" "media"

# Smart Proxy 업데이트 호출
update_smart_proxies

# lock all the templates
sh lock.sh

