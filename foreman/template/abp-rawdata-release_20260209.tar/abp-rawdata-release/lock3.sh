#!/bin/bash

# Foreman 서버 설정
FOREMAN_URL="https://10.1.13.90"
USERNAME="admin"
PASSWORD="root123"
AUTH="-u ${USERNAME}:${PASSWORD}"
HEADER="Content-Type: application/json"

# 파티션 테이블 템플릿의 ID를 가져옵니다.
ptable_ids=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/ptables" | jq '.results | .[] | .id')

# 각 파티션 테이블 템플릿을 순회하며 잠급니다.
for id in $ptable_ids; do
  curl -k -s $AUTH -H "$HEADER" -X PUT -d '{"ptable": {"locked": true}}' "${FOREMAN_URL}/api/ptables/${id}"
  echo "Partition Table Template ID ${id} has been locked."
done

