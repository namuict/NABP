#!/bin/bash

my_location=$(hammer --no-headers --output csv location list --fields Name | head --lines=1)
my_organization=$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)

hammer --no-headers --output csv template list --fields Name > ./existed.txt

if [ "$(grep -x "ABP_checkpoint_health" ./existed.txt)" = "ABP_checkpoint_health" ]; then
  hammer template update --name "ABP_checkpoint_health" --type snippet --file "./template/385.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_health" --type snippet --file "./template/385.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_health_nodes" ./existed.txt)" = "ABP_checkpoint_health_nodes" ]; then
  hammer template update --name "ABP_checkpoint_health_nodes" --type snippet --file "./template/386.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_health_nodes" --type snippet --file "./template/386.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_platformsetup" ./existed.txt)" = "ABP_checkpoint_platformsetup" ]; then
  hammer template update --name "ABP_checkpoint_platformsetup" --type snippet --file "./template/387.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_platformsetup" --type snippet --file "./template/387.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_provisioning" ./existed.txt)" = "ABP_checkpoint_provisioning" ]; then
  hammer template update --name "ABP_checkpoint_provisioning" --type snippet --file "./template/388.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_provisioning" --type snippet --file "./template/388.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_provisioning_new" ./existed.txt)" = "ABP_checkpoint_provisioning_new" ]; then
  hammer template update --name "ABP_checkpoint_provisioning_new" --type snippet --file "./template/449.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_provisioning_new" --type snippet --file "./template/449.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_rexec" ./existed.txt)" = "ABP_checkpoint_rexec" ]; then
  hammer template update --name "ABP_checkpoint_rexec" --type snippet --file "./template/389.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_rexec" --type snippet --file "./template/389.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_checkpoint_rexec_new" ./existed.txt)" = "ABP_checkpoint_rexec_new" ]; then
  hammer template update --name "ABP_checkpoint_rexec_new" --type snippet --file "./template/447.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_checkpoint_rexec_new" --type snippet --file "./template/447.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_environment" ./existed.txt)" = "ABP_environment" ]; then
  hammer template update --name "ABP_environment" --type snippet --file "./template/390.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_environment" --type snippet --file "./template/390.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart CentOS_7.9-Server-Minimal" ./existed.txt)" = "ABP Kickstart CentOS_7.9-Server-Minimal" ]; then
  hammer template update --name "ABP Kickstart CentOS_7.9-Server-Minimal" --type provision --file "./template/391.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart CentOS_7.9-Server-Minimal" --type provision --file "./template/391.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart CentOS_7.9-Server-with-GUI" ./existed.txt)" = "ABP Kickstart CentOS_7.9-Server-with-GUI" ]; then
  hammer template update --name "ABP Kickstart CentOS_7.9-Server-with-GUI" --type provision --file "./template/392.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart CentOS_7.9-Server-with-GUI" --type provision --file "./template/392.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default" ./existed.txt)" = "ABP Kickstart default" ]; then
  hammer template update --name "ABP Kickstart default" --type provision --file "./template/393.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default" --type provision --file "./template/393.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default finish" ./existed.txt)" = "ABP Kickstart default finish" ]; then
  hammer template update --name "ABP Kickstart default finish" --type finish --file "./template/394.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default finish" --type finish --file "./template/394.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default iPXE" ./existed.txt)" = "ABP Kickstart default iPXE" ]; then
  hammer template update --name "ABP Kickstart default iPXE" --type iPXE --file "./template/450.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default iPXE" --type iPXE --file "./template/450.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default iPXE clone" ./existed.txt)" = "ABP Kickstart default iPXE clone" ]; then
  hammer template update --name "ABP Kickstart default iPXE clone" --type iPXE --file "./template/456.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default iPXE clone" --type iPXE --file "./template/456.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default iPXE.org" ./existed.txt)" = "ABP Kickstart default iPXE.org" ]; then
  hammer template update --name "ABP Kickstart default iPXE.org" --type iPXE --file "./template/395.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default iPXE.org" --type iPXE --file "./template/395.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default PXEGrub2" ./existed.txt)" = "ABP Kickstart default PXEGrub2" ]; then
  hammer template update --name "ABP Kickstart default PXEGrub2" --type PXEGrub2 --file "./template/396.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default PXEGrub2" --type PXEGrub2 --file "./template/396.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default PXELinux" ./existed.txt)" = "ABP Kickstart default PXELinux" ]; then
  hammer template update --name "ABP Kickstart default PXELinux" --type PXELinux --file "./template/397.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default PXELinux" --type PXELinux --file "./template/397.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default PXELinux KISTI" ./existed.txt)" = "ABP Kickstart default PXELinux KISTI" ]; then
  hammer template update --name "ABP Kickstart default PXELinux KISTI" --type snippet --file "./template/442.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default PXELinux KISTI" --type snippet --file "./template/442.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart default PXELinux snippet" ./existed.txt)" = "ABP Kickstart default PXELinux snippet" ]; then
  hammer template update --name "ABP Kickstart default PXELinux snippet" --type snippet --file "./template/438.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart default PXELinux snippet" --type snippet --file "./template/438.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Healthcheck" ./existed.txt)" = "ABP Kickstart Healthcheck" ]; then
  hammer template update --name "ABP Kickstart Healthcheck" --type provision --file "./template/398.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Healthcheck" --type provision --file "./template/398.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_Kickstart_Healthcheck_Nodes" ./existed.txt)" = "ABP_Kickstart_Healthcheck_Nodes" ]; then
  hammer template update --name "ABP_Kickstart_Healthcheck_Nodes" --type provision --file "./template/399.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_Kickstart_Healthcheck_Nodes" --type provision --file "./template/399.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_kickstart_kernel_options" ./existed.txt)" = "ABP_kickstart_kernel_options" ]; then
  hammer template update --name "ABP_kickstart_kernel_options" --type snippet --file "./template/400.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_kickstart_kernel_options" --type snippet --file "./template/400.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_kickstart_kernel_options_KISTI" ./existed.txt)" = "ABP_kickstart_kernel_options_KISTI" ]; then
  hammer template update --name "ABP_kickstart_kernel_options_KISTI" --type snippet --file "./template/443.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_kickstart_kernel_options_KISTI" --type snippet --file "./template/443.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart OCP Libvirt Install" ./existed.txt)" = "ABP Kickstart OCP Libvirt Install" ]; then
  hammer template update --name "ABP Kickstart OCP Libvirt Install" --type provision --file "./template/401.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart OCP Libvirt Install" --type provision --file "./template/401.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart OCP Libvirt Install Temp" ./existed.txt)" = "ABP Kickstart OCP Libvirt Install Temp" ]; then
  hammer template update --name "ABP Kickstart OCP Libvirt Install Temp" --type provision --file "./template/402.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart OCP Libvirt Install Temp" --type provision --file "./template/402.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart OCP Provisioner OS" ./existed.txt)" = "ABP Kickstart OCP Provisioner OS" ]; then
  hammer template update --name "ABP Kickstart OCP Provisioner OS" --type provision --file "./template/403.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart OCP Provisioner OS" --type provision --file "./template/403.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Redhat_8.2-Server-Minimal" ./existed.txt)" = "ABP Kickstart Redhat_8.2-Server-Minimal" ]; then
  hammer template update --name "ABP Kickstart Redhat_8.2-Server-Minimal" --type provision --file "./template/404.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Redhat_8.2-Server-Minimal" --type provision --file "./template/404.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Redhat_8.2-Server-with-GUI" ./existed.txt)" = "ABP Kickstart Redhat_8.2-Server-with-GUI" ]; then
  hammer template update --name "ABP Kickstart Redhat_8.2-Server-with-GUI" --type provision --file "./template/405.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Redhat_8.2-Server-with-GUI" --type provision --file "./template/405.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Redhat_8.9-Server-Minimal" ./existed.txt)" = "ABP Kickstart Redhat_8.9-Server-Minimal" ]; then
  hammer template update --name "ABP Kickstart Redhat_8.9-Server-Minimal" --type provision --file "./template/406.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Redhat_8.9-Server-Minimal" --type provision --file "./template/406.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Rocky_8.9-Server-Minimal" ./existed.txt)" = "ABP Kickstart Rocky_8.9-Server-Minimal" ]; then
  hammer template update --name "ABP Kickstart Rocky_8.9-Server-Minimal" --type provision --file "./template/407.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Rocky_8.9-Server-Minimal" --type provision --file "./template/407.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Rocky_8.9-Server-with-GUI" ./existed.txt)" = "ABP Kickstart Rocky_8.9-Server-with-GUI" ]; then
  hammer template update --name "ABP Kickstart Rocky_8.9-Server-with-GUI" --type provision --file "./template/408.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Rocky_8.9-Server-with-GUI" --type provision --file "./template/408.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Kickstart Windriver" ./existed.txt)" = "ABP Kickstart Windriver" ]; then
  hammer template update --name "ABP Kickstart Windriver" --type provision --file "./template/409.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Kickstart Windriver" --type provision --file "./template/409.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed Autoinstall cloud-init user data" ./existed.txt)" = "ABP Preseed Autoinstall cloud-init user data" ]; then
  hammer template update --name "ABP Preseed Autoinstall cloud-init user data" --type user_data --file "./template/410.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed Autoinstall cloud-init user data" --type user_data --file "./template/410.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default finish" ./existed.txt)" = "ABP Preseed default finish" ]; then
  hammer template update --name "ABP Preseed default finish" --type finish --file "./template/411.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default finish" --type finish --file "./template/411.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default iPXE" ./existed.txt)" = "ABP Preseed default iPXE" ]; then
  hammer template update --name "ABP Preseed default iPXE" --type iPXE --file "./template/412.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default iPXE" --type iPXE --file "./template/412.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default iPXE Autoinstall" ./existed.txt)" = "ABP Preseed default iPXE Autoinstall" ]; then
  hammer template update --name "ABP Preseed default iPXE Autoinstall" --type iPXE --file "./template/413.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default iPXE Autoinstall" --type iPXE --file "./template/413.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default PXEGrub2" ./existed.txt)" = "ABP Preseed default PXEGrub2" ]; then
  hammer template update --name "ABP Preseed default PXEGrub2" --type PXEGrub2 --file "./template/414.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default PXEGrub2" --type PXEGrub2 --file "./template/414.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default PXEGrub2 Autoinstall" ./existed.txt)" = "ABP Preseed default PXEGrub2 Autoinstall" ]; then
  hammer template update --name "ABP Preseed default PXEGrub2 Autoinstall" --type PXEGrub2 --file "./template/415.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default PXEGrub2 Autoinstall" --type PXEGrub2 --file "./template/415.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default PXELinux" ./existed.txt)" = "ABP Preseed default PXELinux" ]; then
  hammer template update --name "ABP Preseed default PXELinux" --type PXELinux --file "./template/416.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default PXELinux" --type PXELinux --file "./template/416.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default PXELinux Autoinstall" ./existed.txt)" = "ABP Preseed default PXELinux Autoinstall" ]; then
  hammer template update --name "ABP Preseed default PXELinux Autoinstall" --type PXELinux --file "./template/417.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default PXELinux Autoinstall" --type PXELinux --file "./template/417.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default PXELinux Autoinstall_org" ./existed.txt)" = "ABP Preseed default PXELinux Autoinstall_org" ]; then
  hammer template update --name "ABP Preseed default PXELinux Autoinstall_org" --type PXELinux --file "./template/464.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default PXELinux Autoinstall_org" --type PXELinux --file "./template/464.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed default user data" ./existed.txt)" = "ABP Preseed default user data" ]; then
  hammer template update --name "ABP Preseed default user data" --type user_data --file "./template/418.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed default user data" --type user_data --file "./template/418.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_kernel_options" ./existed.txt)" = "ABP_preseed_kernel_options" ]; then
  hammer template update --name "ABP_preseed_kernel_options" --type snippet --file "./template/419.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_kernel_options" --type snippet --file "./template/419.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_kernel_options_autoinstall" ./existed.txt)" = "ABP_preseed_kernel_options_autoinstall" ]; then
  hammer template update --name "ABP_preseed_kernel_options_autoinstall" --type snippet --file "./template/420.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_kernel_options_autoinstall" --type snippet --file "./template/420.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_kernel_options_autoinstall_org" ./existed.txt)" = "ABP_preseed_kernel_options_autoinstall_org" ]; then
  hammer template update --name "ABP_preseed_kernel_options_autoinstall_org" --type snippet --file "./template/463.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_kernel_options_autoinstall_org" --type snippet --file "./template/463.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_netplan_generic_interface" ./existed.txt)" = "ABP_preseed_netplan_generic_interface" ]; then
  hammer template update --name "ABP_preseed_netplan_generic_interface" --type snippet --file "./template/421.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_netplan_generic_interface" --type snippet --file "./template/421.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_netplan_generic_interface_org" ./existed.txt)" = "ABP_preseed_netplan_generic_interface_org" ]; then
  hammer template update --name "ABP_preseed_netplan_generic_interface_org" --type snippet --file "./template/465.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_netplan_generic_interface_org" --type snippet --file "./template/465.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_netplan_setup" ./existed.txt)" = "ABP_preseed_netplan_setup" ]; then
  hammer template update --name "ABP_preseed_netplan_setup" --type snippet --file "./template/422.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_netplan_setup" --type snippet --file "./template/422.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_preseed_netplan_setup_org" ./existed.txt)" = "ABP_preseed_netplan_setup_org" ]; then
  hammer template update --name "ABP_preseed_netplan_setup_org" --type snippet --file "./template/466.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_preseed_netplan_setup_org" --type snippet --file "./template/466.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed Ubuntu_22.04 Autoinstall cloud-init user data" ./existed.txt)" = "ABP Preseed Ubuntu_22.04 Autoinstall cloud-init user data" ]; then
  hammer template update --name "ABP Preseed Ubuntu_22.04 Autoinstall cloud-init user data" --type user_data --file "./template/423.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed Ubuntu_22.04 Autoinstall cloud-init user data" --type user_data --file "./template/423.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed Ubuntu PC" ./existed.txt)" = "ABP Preseed Ubuntu PC" ]; then
  hammer template update --name "ABP Preseed Ubuntu PC" --type provision --file "./template/424.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed Ubuntu PC" --type provision --file "./template/424.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP Preseed Ubuntu Server" ./existed.txt)" = "ABP Preseed Ubuntu Server" ]; then
  hammer template update --name "ABP Preseed Ubuntu Server" --type provision --file "./template/425.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP Preseed Ubuntu Server" --type provision --file "./template/425.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_runonce" ./existed.txt)" = "ABP_runonce" ]; then
  hammer template update --name "ABP_runonce" --type snippet --file "./template/426.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_runonce" --type snippet --file "./template/426.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_runstep" ./existed.txt)" = "ABP_runstep" ]; then
  hammer template update --name "ABP_runstep" --type snippet --file "./template/427.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_runstep" --type snippet --file "./template/427.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "ABP_setup_parameters_bash" ./existed.txt)" = "ABP_setup_parameters_bash" ]; then
  hammer template update --name "ABP_setup_parameters_bash" --type snippet --file "./template/428.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "ABP_setup_parameters_bash" --type snippet --file "./template/428.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "Boot disk Grub2 EFI - ABP" ./existed.txt)" = "Boot disk Grub2 EFI - ABP" ]; then
  hammer template update --name "Boot disk Grub2 EFI - ABP" --type Bootdisk --file "./template/429.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "Boot disk Grub2 EFI - ABP" --type Bootdisk --file "./template/429.erb" --organization "${my_organization}" --location "${my_location}"
fi
if [ "$(grep -x "kickstart_networking_setup_ib0" ./existed.txt)" = "kickstart_networking_setup_ib0" ]; then
  hammer template update --name "kickstart_networking_setup_ib0" --type snippet --file "./template/430.erb" --organization "${my_organization}" --location "${my_location}"
else
  hammer template create --name "kickstart_networking_setup_ib0" --type snippet --file "./template/430.erb" --organization "${my_organization}" --location "${my_location}"
fi

/usr/bin/rm -f ./existed.txt

