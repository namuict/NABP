#!/bin/bash

# Backup ABP settings and create restore script

function check_cmd(){
   # Check command and return results
   # check_cmd "<name>" "<command> <option1> ..."
   local xxx=${1}
   shift 1
   local yyy=$(${@})
   if [ _"${yyy}" = _ ]; then echo "${xxx} does not exist."; exit 1; fi
   echo -n "${yyy}" | sort | sed ':a;N;$!ba;s|\n| |g'
}

MY_HOSTNAME=$(hostname -f)
HAMMER_CMD=$(check_cmd "hammer command" /usr/bin/which hammer)
JQ_CMD=$(check_cmd "jq command" /usr/bin/which jq)
MY_LOC=$(check_cmd "Location" hammer --no-headers --output csv location list --fields Name | head --lines=1)
MY_ORG=$(check_cmd "Organization" hammer --no-headers --output csv organization list --fields Name | head --lines=1)

MY_OS_IDS=$(check_cmd "OS_Ids" hammer --no-headers --output csv os list --fields Id)
MY_HG_IDS=$(check_cmd "HostGroup_Ids" hammer --no-headers --output csv hostgroup list --fields Id)

function update_config(){
   local CONFIG_KEY=$(echo $1 | tr -d '"')
   local CONFIG_VALUE=$(echo $2 | tr -d '"')
   local CONFIG_FILE=$(echo $3 | tr -d '"')

   if [ ! -f ${CONFIG_FILE} ]; then touch ${CONFIG_FILE}; fi
   GREP_KEY=$(grep -e "^#* *${CONFIG_KEY}=" ${CONFIG_FILE} | awk -F'=' '{print $1}' | tr -d ' ')
   if [ _"${GREP_KEY}" = _ ]; then
     echo "${CONFIG_KEY}=${CONFIG_VALUE}" >> ${CONFIG_FILE}
   else
     sed -i.bak -e "s|#* *${CONFIG_KEY}=.*|${CONFIG_KEY}=${CONFIG_VALUE}|" ${CONFIG_FILE}
   fi
}

MY_MEDIUM_IDS=$(
  for xxx in ${MY_OS_IDS}
    do
    hammer --no-headers --output csv medium list --operatingsystem-id ${xxx} --fields "Id"
  done | tr ' ' '\n' | sort | uniq | tr '\n' ' ' | sed -e 's/[[:space:]]*$//'
)

echo "Backup medium informations"
/usr/bin/mkdir -p ./backup_medum
for xxx in ${MY_MEDIUM_IDS}
do
  echo "Backup medium ID ${xxx} to ./backup_medum/${xxx}.json"
  hammer --no-headers --output json medium info --id ${xxx} > ./backup_medum/${xxx}.json
done

for xxx in ./backup_medum/*
do
  xxx_name=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Name' | tr -s '[:punct:]' '_')
  xxx_path=$(/usr/bin/cat ${xxx} | ${JQ_CMD} -r '.Path')
  echo "Create environments values to ./.abpenv"
  update_config ${xxx_name}_path ${xxx_path} ./.abpenv
done

echo "Backup OS informations"
/usr/bin/mkdir -p ./backup_os
for xxx in ${MY_OS_IDS}
do
  echo "Backup OS ID ${xxx} to ./backup_os/${xxx}.json"
  hammer --no-headers --output json os info --id ${xxx} > ./backup_os/${xxx}.json
done

echo "Backup HostGroup informations"
/usr/bin/mkdir -p ./backup_hostgrp
for xxx in ${MY_HG_IDS}
do
  echo "Backup hostgroup ID ${xxx} to ./backup_hostgrp/${xxx}.json"
  hammer --no-headers --output json hostgroup info --id ${xxx} > ./backup_hostgrp/${xxx}.json
done

echo "Backup HostGroup Parameters"
/usr/bin/mkdir -p ./backup_params

echo -n "" > ./backup_params/hostgrp_params_cmd.bak
hammer --no-headers --output csv hostgroup list --fields name | while read abphostgrp
do
  echo -e "#\n# Backup HostGroup '${abphostgrp}' Parameters\n#">> ./backup_params/hostgrp_params_cmd.bak
  hammer --no-headers --output json hostgroup info --fields Parameters --name "${abphostgrp}" --show-hidden-parameters yes > ./backup_params/hostgrp_${abphostgrp}_params.json
  jq -c '.[][].name' ./backup_params/hostgrp_${abphostgrp}_params.json | while read name_value
  do
    value_value=$(jq -c ".[][] | select(.name==${name_value}) | .value" ./backup_params/hostgrp_${abphostgrp}_params.json)
    parameter_value=$(jq -c ".[][] | select(.name==${name_value}) | .parameter_type" ./backup_params/hostgrp_${abphostgrp}_params.json)
    if [ ${parameter_value} == \"yaml\" -o ${parameter_value} == \"array\" -o ${parameter_value} == \"json\" ]; then
      echo -e "hammer hostgroup set-parameter --hostgroup ${abphostgrp} --name ${name_value} --value '${value_value}' --parameter-type ${parameter_value}" >> ./backup_params/hostgrp_params_cmd.bak
    else
      echo -e "hammer hostgroup set-parameter --hostgroup ${abphostgrp} --name ${name_value} --value ${value_value} --parameter-type ${parameter_value}" >> ./backup_params/hostgrp_params_cmd.bak
    fi
  done
done

##################################################
### Backup Templates

BACKUP_FROM=188 # hammer --no-headers job-template list | sort -n #check last id

### Import partition tables

import_file="./import-partition-table.bash"

/usr/bin/mkdir -p ./partition-table
echo -e "#!/bin/bash\n" > ${import_file}
echo -e "my_location=\$(hammer --no-headers --output csv location list --fields Name | head --lines=1)" >> ${import_file}
echo -e "my_organization=\$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)\n" >> ${import_file}
echo -e "hammer --no-headers --output csv partition-table list --fields Name > ./existed.txt\n" >> ${import_file}
echo "Export partition tables and create import scripts..."

hammer --no-headers --output csv partition-table list | awk -F',' -v id=${BACKUP_FROM} '$1 >= id {print $1 ",\"" $2 "\"," $3}' | \
while IFS=',' read -r xxx yyy zzz
do
  echo -n .
  hammer partition-table dump --id=${xxx} > ./partition-table/${xxx}.erb

  echo -e "if [ \"\$(grep -x ${yyy} ./existed.txt)\" = ${yyy} ]; then" >> ${import_file}
  echo -e "  hammer partition-table update --name ${yyy} --os-family ${zzz} --file \"./partition-table/${xxx}.erb\" --organization \"\${my_organization}\" --location \"\${my_location}\"" >> ${import_file}
  echo -e "else" >> ${import_file}
  echo -e "  hammer partition-table create --name ${yyy} --os-family ${zzz} --file \"./partition-table/${xxx}.erb\" --organization \"\${my_organization}\" --location \"\${my_location}\"" >> ${import_file}
  echo -e "fi" >> ${import_file}

done
echo -e "\n/usr/bin/rm -f ./existed.txt\n" >> ${import_file}

echo
chmod 744 ${import_file}

### Import provisioning templates

import_file="./import-template.bash"

/usr/bin/mkdir -p ./template
echo -e "#!/bin/bash\n" > ${import_file}
echo -e "my_location=\$(hammer --no-headers --output csv location list --fields Name | head --lines=1)" >> ${import_file}
echo -e "my_organization=\$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)\n" >> ${import_file}
echo -e "hammer --no-headers --output csv template list --fields Name > ./existed.txt\n" >> ${import_file}

echo "Export provisioning templates and create import scripts..."
hammer --no-headers --output csv template list | awk -F',' -v id=${BACKUP_FROM} '$1 >= id {print $1 ",\"" $2 "\"," $3}' | \
while IFS=',' read -r xxx yyy zzz
do
  echo -n .
  hammer template dump --id=${xxx} > ./template/${xxx}.erb

  echo -e "if [ \"\$(grep -x ${yyy} ./existed.txt)\" = ${yyy} ]; then" >> ${import_file}
  echo -e "  hammer template update --name ${yyy} --type ${zzz} --file \"./template/${xxx}.erb\" --organization \"\${my_organization}\" --location \"\${my_location}\"" >> ${import_file}
  echo -e "else" >> ${import_file}
  echo -e "  hammer template create --name ${yyy} --type ${zzz} --file \"./template/${xxx}.erb\" --organization \"\${my_organization}\" --location \"\${my_location}\"" >> ${import_file}
  echo -e "fi" >> ${import_file}

done
echo -e "\n/usr/bin/rm -f ./existed.txt\n" >> ${import_file}

echo
chmod 744 ${import_file}

### Import job templates

/usr/bin/mkdir -p ./job-template

echo "Export job templates..."
hammer --no-headers --output csv job-template list --fields Id | awk -v id=${BACKUP_FROM} '$1 >= id' | \
while read xxx
do
  echo -n .
  hammer job-template export --id=${xxx} > ./job-template/${xxx}.erb
  my_name=$(hammer --no-headers --output csv job-template info --id ${xxx} --fields Name)
done
echo

/usr/bin/cat << EOF > ./import-job-template.bash
my_location=\$(hammer --no-headers --output csv location list --fields Name | head --lines=1)
my_organization=\$(hammer --no-headers --output csv organization list --fields Name | head --lines=1)

echo "Import job-templates ..."
for xxx in ./job-template/*
do
  hammer job-template import --overwrite yes --file "\${xxx}" --organization "\${my_organization}" --location "\${my_location}"
done
EOF

chmod 744 ./import-job-template.bash
