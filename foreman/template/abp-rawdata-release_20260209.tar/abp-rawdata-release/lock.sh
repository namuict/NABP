#!/bin/bash

FOREMAN_URL="https://10.149.0.108"
USERNAME="admin"
PASSWORD="root123"
AUTH="-u ${USERNAME}:${PASSWORD}"
HEADER="Content-Type: application/json"
PER_PAGE=20   
PAGE=1

# 초기 페이지 설정
PAGE=1

# 템플릿 ID 저장을 위한 배열 초기화
template_ids=()

# 초기 total 값 설정
total=1 # 임의의 값으로 초기화

# 실제 total 값에 도달할 때까지 페이지를 반복
while [ $((PER_PAGE * (PAGE-1))) -lt $total ]; do
    response=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/provisioning_templates?per_page=$PER_PAGE&page=$PAGE")
    total=$(echo $response | jq '.total') # 전체 템플릿 수 업데이트
    ids=$(echo $response | jq '.results | .[] | .id' | tr -d '"') # 현재 페이지의 템플릿 ID 추출
    if [ -n "$ids" ]; then
        for id in $ids; do
            template_ids+=($id) # 템플릿 ID 배열에 추가
            echo "Collected Template ID: $id"
        done
    fi
    ((PAGE++)) # 다음 페이지로
done

# 수집된 모든 템플릿을 출력
echo "Collected Template IDs: ${template_ids[@]}"


for id in ${template_ids[@]}; do
    echo "Locking Template ID ${id}..."
    curl -k -s $AUTH -H "$HEADER" -X PUT -d '{"provisioning_template": {"locked": true}}' "${FOREMAN_URL}/api/provisioning_templates/${id}" > /dev/null
    echo "Template ID ${id} has been locked."
done




# 초기 페이지 설정
PAGE=1

# 템플릿 ID 저장을 위한 배열 초기화
template_ids=()

# 초기 total 값 설정
total=1 # 임의의 값으로 초기화

# 실제 total 값에 도달할 때까지 페이지를 반복
while [ $((PER_PAGE * (PAGE-1))) -lt $total ]; do
    response=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/job_templates?per_page=$PER_PAGE&page=$PAGE")
    total=$(echo $response | jq '.total') # 전체 템플릿 수 업데이트
    ids=$(echo $response | jq '.results | .[] | .id' | tr -d '"') # 현재 페이지의 템플릿 ID 추출
    if [ -n "$ids" ]; then
        for id in $ids; do
            template_ids+=($id) # 템플릿 ID 배열에 추가
            echo "Collected Template ID: $id"
        done
    fi
    ((PAGE++)) # 다음 페이지로
done

# 수집된 모든 템플릿을 출력
echo "Collected Template IDs: ${template_ids[@]}"


for id in ${template_ids[@]}; do
    echo "Locking Template ID ${id}..."
    curl -k -s $AUTH -H "$HEADER" -X PUT -d '{"job_template": {"locked": true}}' "${FOREMAN_URL}/api/job_templates/${id}" > /dev/null
    echo "Template ID ${id} has been locked."
done


# Get partition table template ids
ptable_ids=$(curl -k -s $AUTH -H "$HEADER" "${FOREMAN_URL}/api/ptables" | jq '.results | .[] | .id')

# Lock templates
for id in $ptable_ids; do
  curl -k -s $AUTH -H "$HEADER" -X PUT -d '{"ptable": {"locked": true}}' "${FOREMAN_URL}/api/ptables/${id}"
  echo "Partition Table Template ID ${id} has been locked."
done

